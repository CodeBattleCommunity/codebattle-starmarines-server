/*
 * © EPAM Systems, 2012  
 */
package com.epam.starwors.bot;

import java.util.ArrayList;
import java.util.Collection;

import com.epam.starwors.galaxy.Move;
import com.epam.starwors.galaxy.Planet;

/**
 * Содержит в себе логику бота. Из основной программы каждый ход вызывается метод {@link step}
 */
public class Logic {
	
	private String botName;
	
	public Logic(String botName) {
		this.botName = botName;
	}

	/**
	 * Основной метод бота, который на основе полученных данных решает какие команды необходимо отправить на сервер 
	 *
	 * @param galaxy текущее состояние планет
	 * @return команды на передвижение юнитов
	 */
	public Collection<Move> step(Collection<Planet> galaxy) {
		// просто вывести на консоль полученные от сервера данные
		for (Planet planet : galaxy) {
			System.out.print(planet);
		}

		// список для хранения комманд
		Collection<Move> moves = new ArrayList<Move>();

		// тут находится вся логика
		for (Planet planet : galaxy) {
			if (botName.equals(planet.getOwner())) {
				moves.add(new Move(planet, planet.getNeighbours().get(0), planet.getUnits()));
				break;
			}
		}

		// выводим команды на консоль перед отправкой
		for (Move move : moves) {
			System.out.println(move);
		}

		return moves;
	}

}
